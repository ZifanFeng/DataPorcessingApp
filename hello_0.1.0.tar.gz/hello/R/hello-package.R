#' @import ggplot2 ggmosaic shinyBS nnet boot
#' @importFrom randomForest randomForest varImpPlot
#' @importFrom DT dataTableOutput renderDataTable datatable
#' @importFrom shiny renderText reactive renderUI renderPlot eventReactive renderPrint fileInput numericInput fluidPage sidebarPanel mainPanel tabsetPanel tabPanel actionButton uiOutput plotOutput verbatimTextOutput textOutput selectInput checkboxGroupInput
"_PACKAGE"
