#' runModeling
#'
#' Run the data cleaning app. User can upload his dataset to the app and the app can
#' build model and do visualization on the dataset.
#'
#' The app does visualization on the distribution of the variables, relationship between two variables and build linear model and random forest model on a sepcific variable.
#'
#' @return let the app run.
#' @export
runModeling <- function (){
  shiny::runApp(
    system.file('shinyapp', ## change to shiny app name
                package='hello')) ## change to your package
  }

