library(shiny)
library(ggplot2)
library(ggmosaic)
library(shinyBS)
library(nnet)
library(DT)
library(randomForest)

fluidPage(
  sidebarPanel(
    fileInput("file", "Choose a File",
              accept = c("text/csv", "text/comma-separated-values,text/plain", ".csv")),
    numericInput("switch", "Minimum Unique Value to be Continuous:",
                 min = 0, max = 10, value = 0, step = 1)
  ),
  mainPanel(
    tabsetPanel(
      tabPanel("OverView",

               h4(textOutput("area",container = span)),
               br(),
               actionButton("varBut","View Distribution of single variable"),
               bsModal("eachVariable","Distribution for single variable", "varBut", size ="large",
                       uiOutput("Valselector"),
                       uiOutput("Groupselector"),
                       plotOutput("plotForSingleVal")),
               br(),

               DT::dataTableOutput("dataTable")
      ),#panel1

      tabPanel("One-to-One model",
               h4("Explore the relations between different variables"),
               uiOutput("Xselector"),
               uiOutput("Yselector"),
               uiOutput("Colselector"),
               plotOutput("varsplot"),
               actionButton("submit0","Build an Model"),

               verbatimTextOutput("bestModelSum"),
               plotOutput("bestGraph")
      ),

      tabPanel("Prediction Model",
               h4("Builde a model"),
               uiOutput("Predict"),
               uiOutput("Variables"),
               actionButton("submit","Submit"),
               tabsetPanel(
                 tabPanel("Linear Model",
                          verbatimTextOutput("Summary"),
                          plotOutput("Accuracy"),
                          plotOutput("Importance"),
                          plotOutput("Resid"),
                          dataTableOutput("Frame")
                 ),
                 tabPanel("Random Forest",
                          verbatimTextOutput("rfSummary"),
                          plotOutput("rfAccuracy"),
                          plotOutput("rfError"),
                          plotOutput("rfImportance")
                 )

               )
      )
    )
  )
)
