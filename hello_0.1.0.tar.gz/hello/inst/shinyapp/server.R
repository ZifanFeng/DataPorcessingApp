library(shiny)
library(ggplot2)
library(ggmosaic)
library(shinyBS)
library(nnet)
library(DT)
library(randomForest)
library(boot)
function(input, output, session){

  myData <- reactive({

    inFile <- input$file

    if (is.null(inFile))
      return(iris)

    raw <- read.csv(inFile$datapath, header = TRUE)
    for(col in names(raw)){
      if(!is.factor(raw[,col]) && length(unique(raw[,col])) <= input$switch){
        raw[,col] <- as.factor(raw[,col])

      }
    }
    raw
  })

  output$area <- renderText({
    paste0("There are ", length(names(myData())), " variables and ", nrow(myData())," observations")
  })#give variables num and obs num

  output$dataTable <- DT::renderDataTable({
    DT::datatable(data.frame(
      Name = names(myData()),
      Class = sapply(myData(), class),
      RangeLength = sapply(myData(), function(d){
        if(is.numeric(d)){
          r = range(d)
          paste(r[1],"~",r[2])}
        else paste(length(unique(d)))
      }),
      BrefSummary = sapply(myData(), function(d){
        if(is.numeric(d)) paste(fivenum(d), collapse = ", ")
        else paste(paste(head(unique(d)), collapse = ", "), "...")
      })
    ), rownames = FALSE)#class and range

  })

  output$Valselector <- renderUI({
    selectInput("valvar","Variable to Show", names(myData()))
  })

  output$Groupselector <- renderUI({
    selectInput("groupvar","Choose a group", names(myData()[sapply(names(myData()), function(x) is.factor(myData()[,x]))]))
  })

  output$plotForSingleVal <- renderPlot({

    if(is.null(input$valvar)){
      return(NULL)
    }
    x <- input$valvar
    g <- ggplot(myData(), aes(myData()[,x]), fill = "red")
    if(input$groupvar!=""){
      g <- ggplot(myData(), aes(myData()[,x], fill = myData()[,input$groupvar]))
    }
    g <- g  + xlab(input$valvar) +
      ylab("Percentage")+
      ggtitle(paste0("Distribution of ", input$valvar))
    if(is.factor(myData()[,x])){
      g <- g + geom_bar( color = "white", aes(y = (..count..)/sum(..count..)))
      g
    }
    else{
      g + geom_histogram(color = "white", aes(y =..density..)) +
        geom_density(col='#0000aa', alpha = .6)} #color adjustment
  })


  #T2 begins
  output$Xselector <- renderUI({
    selectInput("xvar", "X Variable", names(myData())[sapply(names(myData()),
                                                             function(x) {!(is.factor(myData()[,x])&&length(unique(myData()[,x]) )> 10)})])

  })
  output$Yselector <- renderUI({
    selectInput("yvar", "Y Variable", names(myData())[sapply(names(myData()),
                                                             function(x) {!(is.factor(myData()[,x])&&length(unique(myData()[,x])) > 10)})])
  })
  output$Colselector <- renderUI({
    selectInput("col", "Color", names(myData())[sapply(names(myData()),
                                                       function(x) {!(is.factor(myData()[,x])&&length(unique(myData()[,x])) > 10)})])
  })

  types <- function()({
    x <- input$xvar
    y <- input$yvar
    if(is.numeric(myData()[,x])&&is.numeric(myData()[,y]))
      1
    else if(is.factor(myData()[,x])&&is.numeric(myData()[,y]))
      2
    else if(is.numeric(myData()[,x])&&is.factor(myData()[,y]))
      3
    else #if(is.factor(myData()[,x])&&is.factor(myData()[,y]))
      4
  })


  output$varsplot <- renderPlot({
    p <- ggplot(myData())
    x <- input$xvar
    y <- input$yvar
    col <- input$col
    if(!is.null(x)){
      if(types()==1){
        p <- p +
          geom_point(aes(x = myData()[,x], y = myData()[,y], col = myData()[,col]), alpha= .5)+
          labs(col=input$col)
      }
      else if(types()==2){
        p <- p + geom_boxplot(aes(x = myData()[,x], y = myData()[,y]))
        if(is.factor(myData()[,col]))
          p <- p + facet_wrap(~myData()[,col])
      }
      else if(types()==3)
      {p <- p + geom_boxplot(aes(x = myData()[,y], y = myData()[,x])) + coord_flip()
      if(is.factor(myData()[,col]))
        p <- p + facet_wrap(~myData()[,col])
      }
      else if(types()==4){
        df <- as.data.frame(with(myData(), table(unlist(myData()[,x]), unlist(myData()[,y]))))
        p <- ggplot(df) + geom_mosaic(aes(weight = Freq, x = product(df$Var1), fill = df$Var2))
        if(is.factor(myData()[,col]))
          p <- p #+ facet_wrap(~myData()[,col])
      }
      p <- p + xlab(input$xvar) + ylab(input$yvar)}
    p
  })

  bestDegree <- reactive({
    delta <- rep(NA, 10)
    independent <- myData()[,input$xvar]
    hd <- ifelse(length(unique(independent))>10, 10, length(unique(independent))-1)
    dependent <- myData()[, input$yvar]
    data<-data.frame(independent = independent, dependent = dependent)
    for (i in hd:1) {
      fit <- glm(dependent~poly(independent,i), data = data, family = "gaussian")
      #multiDegree <- data.frame(multiDegree)

      delta[i] <- cv.glm(data, fit, K = 10)$delta[1]

    }

    d.min <- which.min(delta)
    d.min
  })

  bestModel <- eventReactive(input$submit0,{
    data <- myData()
    predictor <- poly(data[,input$xvar], bestDegree(), raw = TRUE)
    fit <- glm(data[,input$yvar] ~ predictor, family = "gaussian")
    fit
  })

  combine <- reactive({
    get <- bestModel()$fitted.values
    data.frame("newY" = get, "X" = myData()[,input$xvar])
  })

  output$bestModelSum <- renderPrint({
    if(types()==1){
      # summary(bestModel())
      round(summary(bestModel())$coefficients, 3)
      }
    else{
      "No model between these two variables"
    }
  })

  output$bestGraph <- renderPlot({
    if(types()==1){ plot(myData()[,input$xvar], myData()[,input$yvar], xlab = input$xvar, ylab = input$yvar)
      lines(myData()[,input$xvar], bestModel()$fitted.values, col = "red", lwd = 2)}
  })


  #T3 begin
  output$Predict <- renderUI({
    selectInput("dependent", "Variable to predict", names(myData()))
  })
  output$Variables <- renderUI({
    checkboxGroupInput("independent","Variables to build the model", names(myData()), inline = T)
  })
  index <- reactive({
    sample(1:nrow(myData()), size=0.2*nrow(myData()))
  })
  train <- reactive({
    myData()[-index(),]
  })
  test <- reactive({
    myData()[index(), ]
  })

  type <- reactive({
    check = myData()[, input$dependent]
    if(is.factor(check)){
      if(length(unique(check)) == 2)  0
      else  1
    }
    else  2

  })



  #continuous dependednt
  model <- eventReactive(input$submit,{
    if(type()==2)
    {lm(paste(input$dependent," ~ ",paste(input$independent,collapse="+")), data = train())}
    else if(type()==0)
    {glm(paste(input$dependent, " ~ ", paste(input$independent,collapse="+")), family = "binomial", data = train())}
    else{
      multinom(paste(input$dependent, " ~ ", paste(input$independent,collapse="+")),  data = train())
    }
  })
  combine <- reactive({
    if(type()==1 ){
      result = data.frame(predict(model(), test(), type = "prob"))
    }
    else{
      result = data.frame(predict(model(),test(), type = "response"))
    }
    combine = cbind(result[,1], test()[, input$dependent])
    names(combine) <- c("pred","orig")
    combine
  })
  output$Summary <- renderPrint({
    if(type()!=1)
      summary(model())
    else "No model Now :("
  })
  output$Resid <- renderPlot({
    if(type()==2){
      ggplot(model(), aes(.fitted, .resid)) +
        geom_point() +
        geom_jitter()+
        geom_hline(yintercept = 0)+
        ggtitle("Residual Plot")
    }
  })
  percentRight <- reactive({
    if(type()==2){
      actuals_preds <- combine()
      correlation_accuracy <- cor(actuals_preds)
      min_max_accuracy <- round(mean(apply(actuals_preds, 1, min) / apply(actuals_preds, 1, max)) ,2)
      mape <- round(mean(abs((actuals_preds[,1] - actuals_preds[,2]))/actuals_preds[,2]),2)
      paste("correlation accuracy: ", correlation_accuracy, "    min_max_accuracy: ", min_max_accuracy,"    MAPE: ", mape)
    }
  })
  output$Accuracy <- renderPlot({
    if(type()==2){ggplot(data.frame(combine()), aes(data.frame(combine())[,1],data.frame(combine())[,2]))+
        geom_point(aes(fill = abs(data.frame(combine())[,1]-data.frame(combine())[,2])))+
        labs(fill = "Diff")+
        geom_smooth(alpha=.6)+
        geom_abline(intercept=0,slope=1,size=1, color = "red", alpha=.6)+
        geom_jitter() +
        xlab("Prediction")+
        ylab("Actual Value") +
        ggtitle("Accuracy Plot", subtitle = percentRight())
    }
    else if(type()==0){
      fix <- data.frame(combine())
      fix[,2] <- as.factor(fix[,2])
      ggplot(fix, aes(x = seq(1, nrow(fix)), y = fix[,1], col = fix[,2]))+
        labs(col = "Actual value")+
        geom_point()+
        xlab("ID")+
        ylab("Prediction")+
        geom_abline(intercept =  .5, slope = 0, size = 1, color = "red")+
        ggtitle("Accuracy Plot")
    }
  })
  ipt <- reactive({
    if(type()==2){t <- abs(coef(summary(model()))[,'t value'])
    t <- subset(t, !names(t) %in% c("(Intercept)"))
    t <- data.frame(t)
    names(t) <- "tVal"
    t$names <- row.names(t)
    t}
    else if(type()==0){
      t <- abs(coef(summary(model()))[,'z value'])
      t <- subset(t, !names(t) %in% c("(Intercept)"))
      t <- data.frame(t)
      names(t) <- "tVal"
      t$names <- row.names(t)
      t
    }
  })
  output$Importance <- renderPlot({
    if(type()!=1){
      ggplot(ipt(), aes(x = reorder(names, tVal), y = tVal, fill = tVal)) + #change the color to reflect the positivea and negative realtion
        geom_bar(stat = "identity") +
        xlab("Independent Variables")+
        coord_flip() +
        ggtitle("Ranking of Relevance of Dependent Variables")}
  })

  rfmodel <- eventReactive(input$submit,{

    inde = data.frame(train()[, c(input$independent)])
    names(inde) <- input$independent
    de = train()[, input$dependent]
    randomForest(x = inde, y = de, importance = TRUE, proximity = TRUE, na.action=na.omit)
    # randomForest(paste(input$dependent," ~ ."), #paste(input$independent,collapse="+")),
    #              data = train())$ntree

    #,
    #             importance =  TRUE, proximity = TRUE)

  })
  output$rfSummary <- renderPrint({rfmodel()})

  output$rfAccuracy <- renderPlot({

    pred <- predict(rfmodel(),test())
    orig <- test()[, input$dependent]
    combine <- data.frame(pred, orig)

    ggplot(combine)+
      geom_point(aes(x=combine[,1],y=combine[,2],color=abs(combine[,1]-combine[,2])),alpha=0.7)+
      labs(color ="difference", x = "Predict", y = "Actual")+
      ggtitle('Plotting Error')+
      geom_abline(slope = 1, intercept = 0, color = "red")
  })

  output$rfError <- renderPlot({
    plot(rfmodel())
    if(type()!=2)
    {legend("topright", colnames(rfmodel()$err.rate), fill = 1:length(colnames(rfmodel()$err.rate)))}
  })

  output$rfImportance <- renderPlot({
    varImpPlot(rfmodel())
  })


}


